# WebOS Plasma Full

A browser-based desktop environment inspired by KDE Plasma.

## Features

- React + Vite
- KDE-style glass desktop, launcher and taskbar
- IndexedDB virtual filesystem
- File Manager with create/edit/delete operations
- Terminal with filesystem commands
- APT-like offline package manager
- Software Center
- Persistent Notes
- Calculator
- Paint canvas
- Browser window
- System Monitor
- PWA/service-worker offline shell
- v86 x86 VM integration
- Local ISO/IMG selection for the VM
- GitHub Pages workflow
- Relative paths for repository hosting

## Install

```bash
npm install
npm run dev
```

## Production

```bash
npm run build
npm run preview
```

## GitHub Pages

Push this project to GitHub, enable Pages using GitHub Actions, and the included workflow builds and deploys `dist/`.

## v86

The project uses the v86 npm package. v86 is an x86 emulator that translates x86 machine code to WebAssembly and can run guest operating systems in the browser. It needs firmware and a guest disk/ISO. The VM app lets the user select a local ISO/IMG instead of bundling an operating system image.

The v86 project is distributed under the Simplified BSD License. Check its license and the licenses of any firmware/guest OS images you add.

## Offline

The WebOS shell, local filesystem, installed package metadata and notes are designed to work offline after the site has been opened once and cached. Browser storage limits vary.

A browser cannot become a real Linux kernel or run native Linux packages through an APT repository. The included APT system installs browser applications. The VM provides a separate x86 guest environment.

## Security model

This runs in the browser sandbox. It cannot execute arbitrary host Linux commands, access arbitrary host files without permission, or obtain host root access.